# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
# Create your views here.
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.template import loader
from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .forms import DriverLoginForm
from .models import Traffic,OverSpeed
# Create your views here.
import requests
from ast import literal_eval
import numpy as np
import cv2
from django.http import JsonResponse

from Vehicles_detection import predict as p

@csrf_exempt
def traffic(request):
	if request.POST:
		t = Traffic(Route=request.POST['Route'], Density=request.POST['Density'], Date = request.POST['Date'])
		t.save()
	else:
		URL1="https://io.adafruit.com/api/v2/santhoshv15/feeds/route/data?X-AIO-Key=ab8d030e654149519aa7fb75a2cab44d"
		URL2="https://io.adafruit.com/api/v2/santhoshv15/feeds/density/data?X-AIO-Key=ab8d030e654149519aa7fb75a2cab44d"
		URL3="https://io.adafruit.com/api/v2/santhoshv15/feeds/date/data?X-AIO-Key=ab8d030e654149519aa7fb75a2cab44d"
		r = requests.get(url = URL1)
		data1 = r.json()
		print(data1[0]['value'])
		print
		r = requests.get(url = URL2)
		data2 = r.json()
		print(data2[0]['value'])
		print
		r = requests.get(url = URL3)
		data3 = r.json()
		print(data3[0]['value'])
		print
		t = Traffic(Route=data1[0]['value'], Density=data2[0]['value'], Date = data3[0]['value'])
		t.save()
	Traffic_list = Traffic.objects.all()
	return render(request,'samp.html',context={'data':Traffic_list} )

VN=""
pvnum=[]
cvnum=[]
@csrf_exempt
def overspeed(request):
    os = OverSpeed(Route=request.POST['Route'], Speed=request.POST['Speed'], Date = request.POST['Date'], Vehiclenum=request.POST['Vehiclenum'])
    os.save()
    return HttpResponse("Logged in successfully")

@csrf_exempt
def test(request):
    Image=np.array(literal_eval(request.POST["Image"]))
    p(Image)
    data = {
        'Count': p(Image),
    }
    return JsonResponse(data)

def login(request):
	form = DriverLoginForm(request.POST)
	print "***"
        if form.is_valid():
		global VN
		VN=form.cleaned_data['Vehiclenum']
		global pvnum
		pvnum = OverSpeed.objects.filter(Vehiclenum=VN)
		pop(request)
		return render(request,'home.html',context={'data':pvnum} )
	else:
        	form = DriverLoginForm(request.POST or None)
	return render(request, 'contacts.html', {'form': form})

	
def pop(request):
	#while(1):
		global cvnum
		cvnum = OverSpeed.objects.filter(Vehiclenum=VN)
		#print (len(cvnum),len(pvnum))
		if len(pvnum)<len(cvnum):
			global pvnum
			pvnum=cvnum
			return
