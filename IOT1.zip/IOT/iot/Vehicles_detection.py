import cv2
import numpy as np
def predict(im):
	car_cascade = cv2.CascadeClassifier('/home/santosh/Videos/IOT/iot/cars.xml')
	im=np.array(im)
	im=im.astype(np.uint8)
	gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
	print gray.shape 
	cars = car_cascade.detectMultiScale(gray, 1.1, 1)
	for (x,y,w,h) in cars:
	    cv2.rectangle(im,(x,y),(x+w,y+h),(0,0,255),2)
	print len(cars) 
	cv2.imshow('video2', im)
	cv2.waitKey(0)
	cv2.destroyAllWindows()
	return len(cars)
